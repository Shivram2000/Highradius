package com.highradius.implementation;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
//import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.highradius.model.Invoice;
import com.highradius.connection.DatabaseConnection;

public class InvoiceDaoImpl implements InvoiceDao{
	int nos=0;
	private static final String insert_invoice = "INSERT INTO h2h_oap"+ 
			"(customer_Order_Id,sales_Org,company_Code,customer_Number"
			+",distribution_Channel,order_Currency"
			+",order_Creation_Date,amount_In_Usd,Order_amount,sl_no)VALUES"+
			"(?,?,?,?,?,?,?,?,?,?)";
    
	private static  final String select_invoice = "select * from h2h_oap where";
	private static  final String select_all = "select * from h2h_oap";
	private static final String  delete_invoice = "delete from h2h_oap where sl_no=?;";
	private static final String update_invoice = "update h2h_oap set order_Currency=?,company_Code=?,distribution_Channel=? where sl_no=?";
	
	public HashMap<Object,Object> addInvoice(Invoice invoice)throws Exception
	{
		HashMap<Object,Object> Response = new HashMap<Object,Object>();
		//DatabaseConnection connection=new DatabaseConnection;
		try(Connection conn=DatabaseConnection.getConn();
				PreparedStatement statement=conn.prepareStatement(insert_invoice);)
		{
			nos++;
			statement.setInt(1, invoice.getCustomer_Order_Id());
			statement.setInt(2, invoice.getSales_Org());
			statement.setInt(3, invoice.getCompany_Code());
			statement.setInt(4, invoice.getCustomer_Number());
			statement.setString(5, invoice.getDistribution_Channel());
			statement.setString(6, invoice.getOrder_Currency());
			statement.setString(7,invoice.getOrder_Creation_Date());
			statement.setDouble(8, invoice.getAmount_In_Usd());
			statement.setDouble(9, invoice.getOrder_Amount());
			statement.setInt(10,nos);
			
			System.out.println(statement);
			if(statement.executeUpdate()>0) {
				Response.put("inserted", true);
			}else {
				Response.put("inserted", false);
			}
	
		}catch(Exception E) {
			Response.put("inserted", false);
			E.printStackTrace();
		}
		return Response;
	}
	public List<Invoice> AdvSearch(String customerOrderId,String salesOrg ,String distributionChannel) throws Exception
	{
		List<Invoice> invoices=new ArrayList<>();
		String additionalQuery = " ";
		
		if(customerOrderId != null && !customerOrderId.equals("")) {
			additionalQuery = additionalQuery + " customer_Order_Id=" + customerOrderId+" AND";
		}
		if(salesOrg != null && !salesOrg.equals("")) {
			additionalQuery = additionalQuery + " sales_Org=" + salesOrg+" AND";
		}
		if(distributionChannel != null && !distributionChannel.equals(" ")) {
			additionalQuery = additionalQuery + " distribution_Channel='" + distributionChannel+"' AND";
		}
		String complete_query=select_invoice+additionalQuery;
		String final_query=(complete_query).substring(0,complete_query.length()-3);
		System.out.println(final_query);
		
		try(Connection conn=DatabaseConnection.getConn();
				PreparedStatement statement=conn.prepareStatement(final_query);)
		{
			ResultSet r=statement.executeQuery();
			while(r.next())
			{
				 int id=r.getInt("sl_no");
				 int customer_Order_Id,sales_Org,company_Code,customer_Number;
			     String distribution_Channel,order_Currency,order_Creation_Date;
			     double amount_In_Usd,order_Amount;
			    
			        customer_Order_Id=r.getInt("customer_Order_Id");
			        sales_Org=r.getInt("sales_Org");
			        company_Code=r.getInt("company_Code");
			        customer_Number=r.getInt("customer_Number");
			        distribution_Channel=r.getString("distribution_Channel");
			        order_Currency=r.getString("order_Currency");
			        order_Creation_Date=r.getString("order_Creation_Date");
					amount_In_Usd=r.getDouble("amount_In_Usd");
					order_Amount=r.getDouble("order_Amount");

				invoices.add(new Invoice(id,customer_Order_Id,sales_Org,company_Code,customer_Number,distribution_Channel,
						order_Currency,amount_In_Usd,order_Amount,order_Creation_Date));

			}
		}
		return invoices;
	}
	
	public HashMap<Object,Object> deleteInvoice(int sl_no)throws Exception
		{
			HashMap<Object,Object> Response = new HashMap<Object,Object>();
			try(Connection conn=DatabaseConnection.getConn();
					PreparedStatement statement=conn.prepareStatement(delete_invoice);)
			{
				statement.setInt(1, sl_no);
				
				if(statement.executeUpdate()>0) {
					Response.put("inserted", true);
				}else {
					Response.put("inserted", false);
				}
			}
			catch (Exception e) {
				// TODO: handle exception
			}
			return Response;
		}
		public HashMap<Object,Object> updateInvoice(Invoice invoice)throws Exception
		{
			HashMap<Object,Object> Response = new HashMap<Object,Object>();
			try(Connection conn=DatabaseConnection.getConn();
					PreparedStatement statement=conn.prepareStatement(update_invoice);)
			{
				statement.setString(1,invoice.getOrder_Currency());
				statement.setInt(2, invoice.getCompany_Code());
				statement.setString(3,invoice.getDistribution_Channel());
				statement.setInt(4, invoice.getSl_no());
				
				System.out.println(statement);
				if(statement.executeUpdate()>0) {
					Response.put("inserted", true);
				}else {
					Response.put("inserted", false);
				}
				
			}
			catch (Exception e) {
				e.printStackTrace();
			}
			return Response;
		}
			
		//select records by id
		public List<Invoice> searchInvoice(String customerOrderId)throws Exception
		{
			List<Invoice> invoices=new ArrayList<>();
			String additionalQuery = " ";
			
			if(customerOrderId != null && !customerOrderId.equals("")) {
				additionalQuery = additionalQuery + " customer_Order_Id=" + customerOrderId+" AND";
			}
			String complete_query=select_invoice+additionalQuery;
			String final_query=(complete_query).substring(0,complete_query.length()-3);
			System.out.println(final_query);
			
			try(Connection conn=DatabaseConnection.getConn();
					PreparedStatement statement=conn.prepareStatement(final_query);)
			{
				ResultSet r=statement.executeQuery();

				while(r.next())
				{
                     int sl_no,sales_Org,company_Code,customer_Number,customer_Order_Id;
				     String distribution_Channel,order_Currency,order_Creation_Date;
				     double amount_In_Usd,order_Amount;
				     					 
					    sl_no=r.getInt("sl_no");
					    customer_Order_Id=r.getInt("customer_Order_Id");				        
					    sales_Org=r.getInt("sales_Org");
				        company_Code=r.getInt("company_Code");
				        customer_Number=r.getInt("customer_Number");
				        distribution_Channel=r.getString("distribution_Channel");
				        order_Currency=r.getString("order_Currency");
				        order_Creation_Date=r.getString("order_Creation_Date");
						amount_In_Usd=r.getDouble("amount_In_Usd");
						order_Amount=r.getDouble("order_Amount");
						invoices.add(new Invoice(sl_no,customer_Order_Id,sales_Org,company_Code,customer_Number,distribution_Channel,
								order_Currency,amount_In_Usd,order_Amount,order_Creation_Date));

					}
				}
				return invoices;
			}

		public List<Invoice> selectAllInvoice()
		{
			List<Invoice> invoice=new ArrayList<>();
			try(Connection conn=DatabaseConnection.getConn();
					PreparedStatement statement=conn.prepareStatement(select_all);)
			{
				
				ResultSet r=statement.executeQuery();
		
		
				while(r.next())
				{
					 int id=r.getInt("sl_no");
					 int customer_Order_Id,sales_Org,company_Code,customer_Number;
				     String distribution_Channel,order_Currency,order_Creation_Date;
				     double amount_In_Usd,order_Amount;
					 
					    customer_Order_Id=r.getInt("customer_Order_Id");
				        sales_Org=r.getInt("sales_Org");
				        company_Code=r.getInt("company_Code");
				        customer_Number=r.getInt("customer_Number");
				        distribution_Channel=r.getString("distribution_Channel");
				        order_Currency=r.getString("order_Currency");
				        order_Creation_Date=r.getString("order_Creation_Date");
						amount_In_Usd=r.getDouble("amount_In_Usd");
						order_Amount=r.getDouble("order_Amount");
		
		
					invoice.add(new Invoice(id,customer_Order_Id,sales_Org,company_Code,customer_Number,distribution_Channel,
							order_Currency,amount_In_Usd,order_Amount,order_Creation_Date));
		
				}
				nos=invoice.size();
			} 
			   catch (Exception e) {
				e.printStackTrace();
			}
			return invoice;
		}
		
	
}

