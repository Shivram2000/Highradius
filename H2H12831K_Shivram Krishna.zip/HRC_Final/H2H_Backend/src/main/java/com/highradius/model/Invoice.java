package com.highradius.model;

import java.sql.Date;

public class Invoice {
	int sl_no,customer_Order_Id,sales_Org,company_Code,customer_Number;
    String distribution_Channel,order_Currency,order_Creation_Date;
    double amount_In_Usd,order_Amount;
 
	//constructor without Sl_no
	 public Invoice(int customer_Order_Id, int sales_Org, int company_Code, int customer_Number, String distribution_Channel,
			String order_Currency, double amount_In_Usd, double order_Amount, String order_Creation_Date) {
		super();
		this.customer_Order_Id = customer_Order_Id;
		this.sales_Org = sales_Org;
		this.company_Code = company_Code;
		this.customer_Number = customer_Number;
		this.distribution_Channel = distribution_Channel;
		this.order_Currency = order_Currency;
		this.amount_In_Usd = amount_In_Usd;
		this.order_Amount = order_Amount;
		this.order_Creation_Date = order_Creation_Date;
	}
	//constructor with Sl_no
	 public Invoice(int sl_no,int customer_Order_Id, int sales_Org, int company_Code, int customer_Number, String distribution_Channel,
				String order_Currency, double amount_In_Usd, double order_Amount, String order_Creation_Date) {
			super();
			this.sl_no=sl_no;
			this.customer_Order_Id = customer_Order_Id;
			this.sales_Org = sales_Org;
			this.company_Code = company_Code;
			this.customer_Number = customer_Number;
			this.distribution_Channel = distribution_Channel;
			this.order_Currency = order_Currency;
			this.amount_In_Usd = amount_In_Usd;
			this.order_Amount = order_Amount;
			this.order_Creation_Date = order_Creation_Date;
	}
	public int getSl_no() {
		return sl_no;
	}
	public void setSl_no(int sl_no) {
		this.sl_no = sl_no;
	}
	public int getCustomer_Order_Id() {
		return customer_Order_Id;
	}
	public void setCustomer_Order_Id(int customer_Order_Id) {
		this.customer_Order_Id = customer_Order_Id;
	}
	public int getSales_Org() {
		return sales_Org;
	}
	public void setSales_Org(int sales_Org) {
		this.sales_Org = sales_Org;
	}
	public int getCompany_Code() {
		return company_Code;
	}
	public void setCompany_Code(int company_Code) {
		this.company_Code = company_Code;
	}
	public int getCustomer_Number() {
		return customer_Number;
	}
	public void setCustomer_Number(int customer_Number) {
		this.customer_Number = customer_Number;
	}
	public String getDistribution_Channel() {
		return distribution_Channel;
	}
	public void setDistribution_Channel(String distribution_Channel) {
		this.distribution_Channel = distribution_Channel;
	}
	public String getOrder_Currency() {
		return order_Currency;
	}
	public void setOrder_Currency(String order_Currency) {
		this.order_Currency = order_Currency;
	}
	public double getAmount_In_Usd() {
		return amount_In_Usd;
	}
	public void setAmount_In_Usd(double amount_In_Usd) {
		this.amount_In_Usd = amount_In_Usd;
	}
	public double getOrder_Amount() {
		return order_Amount;
	}
	public void setOrder_Amount(double order_Amount) {
		this.order_Amount = order_Amount;
	}
	public String getOrder_Creation_Date() {
		return order_Creation_Date;
	}
	public void setOrder_Creation_Date(String order_Creation_Date) {
		this.order_Creation_Date = order_Creation_Date;
	}
	
}
