import axios from "axios";
export const keys = [
    "sl_No",
    "customer_Order_Id",
    "sales_Org",
    "company_Code",
    "customer_Number",
    "distribution_Channel",
    "order_Currency",
    "order_Creation_Date",
    "amount_In_Usd",
    "order_Amount",
];
export const getData = async () => {
  let response = await axios.get("http://localhost:8080/H2H_Backend/",{mode:'cors'});

  console.log(response);
  return response.data;
};
