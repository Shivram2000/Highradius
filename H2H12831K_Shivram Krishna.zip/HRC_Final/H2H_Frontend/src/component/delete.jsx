import React, { Component } from "react";
import { wait } from "@testing-library/user-event/dist/utils";
import axios from "axios";

class DeleteData extends Component {
  state = {
    invoice: this.props.selectedRows[0],
  };
  submitPopup = async () => {
    console.log(this.props.selectedRows.length);
    console.log(this.state.invoice);
    for (const [key, val] of Object.entries(this.state.invoice)) {
      if (
        key !== "order_Creation_Date" &&
        key !== "customer_Order_Id" &&
        (val === "" || val === undefined)
      ) {
        wait(3000).then(
          console.log("The required field " + key + " is missing")
        );

        return;
      } else {
        console.log(key + "correct");
      }
    }

    try {
      let resp = await axios.post(
        "http://localhost:8080/H2H_Backend/deleteInvoice",
        new URLSearchParams(this.state.invoice),
        {}
      );
      console.log(resp);
    } catch (err) {
      wait(3000).then(console.log("Error in updating"));
    }
    this.props.stateHandler(false);
    window.location.reload(false);
  };
  render() {
    return this.props.deleteData ? (
      ""
    ) : (
      <div className="popup">
        <div className="popup-inner-edit-data">
          <div className="grid-container-edit-data">
            <h1
              className="grid-rowitem-1"
              style={{ color: "white", gridColumnStart: 1, gridColumnEnd: 3 }}
            >
              Delete Invoices?
            </h1>
            <h3
              className="grid-rowitem-2"
              style={{ color: " #a9a9a9", gridColumnStart: 1, gridColumnEnd: 3 }}
            >
              Are you sure you want to delete these record[s]?
            </h3>
            <button
              className="btn btn-default m-2 grid-colitem-1 grid-rowitem-3"
              onClick={this.submitPopup}
            >
              DELETE
            </button>
            <button
              className="btn btn-default m-2 grid-colitem-2 grid-rowitem-3"
              onClick={this.props.handler}
            >
              CANCEL
            </button>
          </div>
        </div>
      </div>
    );
  }
}

export default DeleteData;