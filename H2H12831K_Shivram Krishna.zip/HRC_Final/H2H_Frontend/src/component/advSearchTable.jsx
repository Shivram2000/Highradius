import React from "react";
import { DataGrid } from "@mui/x-data-grid";
import Box from "@mui/material/Box";

export default function AdvSearchTable({ data, selectedRows, selectRow }) {
  const columns = [
    {
      field: "sl_no",
      headerName: "Sl No",
      width: 70,
      headerClassName: "super-app-theme--header",
      headerAlign: "center",
    },
    {
      field: "customer_Order_Id",
      headerName: "Customer Order Id",
      width: 100,
      headerClassName: "super-app-theme--header",
      headerAlign: "center",
    },
    {
      field: "sales_Org",
      headerName: "Sales Org",
      width: 150,
      headerClassName: "super-app-theme--header",
      headerAlign: "center",
    },
    {
      field: "company_Code",
      headerName: "Company Code",
      width: 150,
      headerClassName: "super-app-theme--header",
      headerAlign: "center",
    },
    {
      field: "customer_Number",
      headerName: "Customer Number",
      width: 100,
      headerClassName: "super-app-theme--header",
      headerAlign: "center",
    },
    {
      field: "distribution_Channel",
      headerName: "Distribution Channel",
      width: 150,
      headerClassName: "super-app-theme--header",
      headerAlign: "center",
    },
    {
      field: "order_Currency",
      headerName: "Order Currency",
      width: 150,
      headerClassName: "super-app-theme--header",
      headerAlign: "center",
    },
    {
      field: "amount_In_Usd",
      headerName: "Amount In Usd",
      width: 150,
      headerClassName: "super-app-theme--header",
      headerAlign: "center",
    },

    {
      field: "order_Creation_Date",
      headerName: "Order Creation Date",
      width: 150,
      headerClassName: "super-app-theme--header",
      headerAlign: "center",
    },
    {
      field: "order_Amount",
      headerName: "order_Amount",
      width: 150,
      headerClassName: "super-app-theme--header",
      headerAlign: "center",
    },
  ];

  const rows = data;
  console.log("table seacrh data", data);
  return (
    <div style={{ height: 420, width: "100%", position: "sticky",overflow:"hidden" }}>
      <Box
        sx={{
          height: "100%",
          width: 1,
          "& .super-app-theme--header": {
            backgroundColor: "#5A5A5A",
            color: "white",
          },
          backgroundColor: "#5A5A5A",
        }}
      >
        <DataGrid
          rows={rows}
          columns={columns}
          rowsPerPageOptions={[5,10,20,50,100]}
          checkboxSelection
          getRowId={(row) => row.sl_no}
          selectionModel={selectedRows.map((e) => e.sl_no)}
          onSelectionModelChange={(ids) => {
          selectRow(rows.filter((e) => ids.indexOf(e.sl_no) != -1));
          }}
          sx={{
            "& .MuiToolbar-root": {
              color: "white",
            },
            border: "none",
            backgroundColor: "#5A5A5A",
            color: "white",
            "& .MuiDataGrid-columnSeparator--sideRight": {
              display: "none",
            },
            "& .MuiDataGrid-columnHeaderTitle": {
              color: "white",

              textOverflow: "clip",
              whiteSpace: "break-spaces",
              lineHeight: 1,
            },
          }}
        />
      </Box>
    </div>
  );
}