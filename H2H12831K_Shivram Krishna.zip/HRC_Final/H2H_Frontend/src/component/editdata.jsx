import React, { Component } from "react";
import TextField from "@mui/material/TextField";
import "./popup.css";
import { wait } from "@testing-library/user-event/dist/utils";
import axios from "axios";

class EditData extends Component {
  state = {
    invoice: this.props.selectedRows[0],
  };
  render() {
    console.log("Edit Data invoked", this.props.trigger);
    console.log(this.state.invoice);
    return !this.props.trigger ? (
      ""
    ) : (
      <div className="popup">
        <div className="popup-inner-edit-data">
          <div className="grid-container-edit-data">
            <h1
              className="grid-rowitem-1"
              style={{ color: "white", gridColStart: 1, gridColEnd: 4 }}
            >
              Edit
            </h1>
            
            <TextField
              name="order_Currency"
              color="primary"
              type="text"
              className="grid-colitem-1 grid-rowitem-2"
              variant="filled"
              sx={{ input: { backgroundColor: "white" } }}
              label="Order Currency"
              value={this.state.invoice["order_Currency"]}
              onChange={this.fieldValueChange}
            ></TextField>
            <TextField
              name="company_Code"
              color="primary"
              type="text"
              className="grid-colitem-2 grid-rowitem-2"
              variant="filled"
              sx={{ input: { backgroundColor: "white" } }}
              label="Company Code"
              value={this.state.invoice["company_Code"]}
              onChange={this.fieldValueChange}
            />
            <TextField
              name="distribution_Channel"
              color="primary"
              type="text"
              className="grid-colitem-1 grid-rowitem-3"
              variant="filled"
              sx={{ input: { backgroundColor: "white" } }}
              label="Distribution Channel"
              value={this.state.invoice["distribution_Channel"]}
              onChange={this.fieldValueChange}
            />
            <button
              className="btn btn-default m-2 grid-colitem-1 grid-rowitem-4"
              onClick={this.submitPopup}
            >
              Edit
            </button>
            <button
              className="btn btn-default m-2 grid-colitem-2 grid-rowitem-4"
              onClick={this.props.handler}
            >
              Cancel
            </button>
          </div>
        </div>
      </div>
    );
  }
  fieldValueChange = (e, newValue) => {
    const newinvoice = this.state.invoice;
    newinvoice[e.target.name] = e.target.value;
    this.setState({ invoice: newinvoice });
  };

  submitPopup = async () => {
    console.log(this.props.selectedRows.length);
    console.log(this.state.invoice);
    for (const [key, val] of Object.entries(this.state.invoice)) {
      if (
        key !== "order_Creation_Date" &&
        key !== "customer_Order_Id" &&
        (val === "" || val === undefined)
      ) {
        wait(3000).then(
          console.log("The required field " + key + " is missing")
        );

        return;
      } else {
        console.log(key + "correct");
      }
    }

    try {
      let resp = await axios.post(
        "http://localhost:8080/H2H_Backend/updateInvoice",
        new URLSearchParams(this.state.invoice),
        {}
      );
      console.log(resp);
    } catch (err) {
      wait(3000).then(console.log("Error in updating"));
    }
    this.props.stateHandler(false);
    window.location.reload(false);
  };
}

export default EditData;
