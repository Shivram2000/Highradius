import React, { Component } from "react";
import "./popup.css";
import TextField from "@mui/material/TextField";
import { wait } from "@testing-library/user-event/dist/utils";
import axios from "axios";
export default class AddData extends Component {
  state = {
    invoice: {
        customer_Order_Id:undefined,sales_Org:undefined,company_Code:undefined,customer_Number:undefined,
        distribution_Channel:undefined,order_Currency:undefined,amount_In_Usd:undefined,order_Creation_Date:undefined,},
  };
  fieldValueChange = (e, newValue) => {
    e.persist();
    const newInvoice = this.state.invoice;
    newInvoice[e.target.name] = e.target.value;
    this.setState({ invoice: newInvoice });
  };
  submitPopup = async () => {
    console.log(this.state.invoice);

    for (const [key, val] of Object.entries(this.state.invoice)) {
      if (key !== "order_Creation_Date" && (val === "" || val === undefined)) {
        wait(3000).then(
          console.log("The required field " + key + " is missing")
        );

        return;
      } else {
        console.log(key + "correct");
      }
    }

    try {
      let resp = await axios.post(
        "http://localhost:8080/H2H_Backend/addInvoice",
        new URLSearchParams(this.state.invoice),
        {}
      );
      console.log(resp);
    } catch (err) {
      wait(3000).then(console.log("Error in updating"));
    }
    this.props.stateHandler(false);
    window.location.reload(false);
  };
  render() {
    return this.props.trigger ? (
      <div className="popup">
        <div className="popup-inner">
          <h3
            style={{
              color: "white",
            }}
          >
            Add Data
          </h3>
          <div className="grid-container">
            <TextField
              name="customer_Order_Id"
              color="primary"
              className="grid-colitem-1 grid-rowitem-1"
              variant="filled"
              sx={{ input: { backgroundColor: "white" } }}
              label="Customer Order Id"
              onChange={this.fieldValueChange}
            />
            <TextField
              name="sales_Org"
              color="primary"
              className="grid-colitem-2 grid-rowitem-1"
              variant="filled"
              sx={{ input: { backgroundColor: "white" } }}
              label="Sales Org"
              onChange={this.fieldValueChange}
            />
            <TextField
              name="company_Code"
              color="primary"
              className="grid-colitem-3 grid-rowitem-1"
              variant="filled"
              sx={{ input: { backgroundColor: "white" } }}
              label="Company Code"
              onChange={this.fieldValueChange}
            />
            <TextField
              name="customer_Number"
              color="primary"
              className="grid-colitem-4 grid-rowitem-1"
              variant="filled"
              sx={{ input: { backgroundColor: "white" } }}
              label="Customer Number"
              onChange={this.fieldValueChange}
            />
            <TextField
              name="distribution_Channel"
              color="primary"
              className="grid-colitem-1 grid-rowitem-2"
              variant="filled"
              sx={{ input: { backgroundColor: "white" } }}
              label=" Distribution Channel"
              onChange={this.fieldValueChange}
            />
            <TextField
              name="order_Currency"
              color="primary"
              className="grid-colitem-2 grid-rowitem-2"
              variant="filled"
              sx={{ input: { backgroundColor: "white" } }}
              label="Order Currency"
              onChange={this.fieldValueChange}
            />

            <TextField
              name="amount_In_Usd"
              color="primary"
              className="grid-colitem-3 grid-rowitem-2"
              variant="filled"
              sx={{ input: { backgroundColor: "white" } }}
              label="Amount In Usd"
              onChange={this.fieldValueChange}
            />

            <TextField
              name="order_Creation_Date"
              color="primary"
              type="date"
              className="grid-colitem-4 grid-rowitem-2"
              variant="filled"
              sx={{ input: { backgroundColor: "white" } }}
              InputLabelProps={{
                shrink: true,
              }}
              label="Order Creation Date"
              onChange={this.fieldValueChange}
            />
            <button
              className="btn btn-default m-2 grid-colitem-2 grid-rowitem-5"
              onClick={this.submitPopup}
            >
              ADD
            </button>
            <button
              className="btn btn-default m-2 grid-colitem-3 grid-rowitem-5"
              onClick={this.props.handler}
            >
              CLOSE 
            </button>
          </div>
        </div>
      </div>
    ) : (
      ""
    );
  }
}
